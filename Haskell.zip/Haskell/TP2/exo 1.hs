nbPos :: Int -> Int
nbPos 0 = 0
nbPos n = 1 + nbPos (n `div` 2)