to_binary :: Int -> [Char]
to_binary  0 = "0"
to_binary  1 = "1"
to_binary n = to_binary (n `div` 2) ++ (show (mod n 2))
    