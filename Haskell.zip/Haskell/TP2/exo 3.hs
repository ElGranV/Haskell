to_decimal :: [Char] -> Int
to_decimal [] = 0
to_decimal (x:xs)
    |x=='1' = 2^(length (x:xs) - 1) + to_decimal xs 
    |otherwise = to_decimal xs