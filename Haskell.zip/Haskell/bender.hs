import Data.List
import System.IO
import Control.Monad
data Point = Point {px :: Int, py :: Int} deriving (Show)
data Bot = Bot {x :: Int, y :: Int, direction :: Char, casseur :: Bool, inverted :: Bool, historique :: [String], nombre_mouvements :: Int}


getSymbolXPos :: Eq a => [[a]] -> a -> Int
getSymbolXPos grille symbol = div (head $ findIndices (==symbol) (concat grille)) (length (grille!!0))
getSymbolYPos :: Eq a => [[a]] -> a -> Int
getSymbolYPos grille symbol = mod (head $ findIndices (==symbol) (concat grille)) (length (grille!!0))

getSymbolCoord :: Eq a => [[a]] -> a -> Point
getSymbolCoord grille symbol = Point (getSymbolXPos grille symbol) (getSymbolYPos grille symbol)

getStartPoint :: [String] -> Point
getStartPoint grille = getSymbolCoord grille '@'

getCabPoint :: [[Char]] -> Point
getCabPoint grille = getSymbolCoord grille '$'

--getTelelportPoints  = 

naturalNext :: Bot -> [[Char]] -> Char
naturalNext bot grille
    |direction bot == 'S' = (grille !! (x bot +1)) !! (y bot)
    |direction bot == 'E' = (grille !! (x bot)) !! (y bot +1)
    |direction bot == 'W' = (grille !! (x bot)) !! (y bot -1)
    |direction bot == 'N' = (grille !! (x bot -1)) !! (y bot)
    |otherwise = 'S'


nextPos :: Bot -> Point
nextPos bot
    |direction bot == 'S' = Point (x bot +1) (y bot)
    |direction bot == 'E' = Point (x bot) (y bot + 1)
    |direction bot == 'W' = Point (x bot) (y bot -1)
    |direction bot == 'N' = Point (x bot - 1) (y bot)

actualPos :: Bot -> [String] -> Char
actualPos bot grille = grille !! (x bot) !! (y bot)

priorityDirection :: Bot -> [[Char]] -> [Char] -> Char
priorityDirection bot grille dirs
    |not ((naturalNext bot {direction = dirs !! 0} grille) `elem` "#X") = dirs !! 0
    |not ((naturalNext bot {direction = dirs !! 1} grille) `elem` "#X") = dirs !! 1
    |not ((naturalNext bot {direction = dirs !! 2} grille) `elem` "#X") = dirs !! 2
    |not ((naturalNext bot {direction = dirs !! 3} grille) `elem` "#X") = dirs !! 3
    |otherwise = dirs !! 0

defineState bot grille
    |actualPos bot grille == 'I' = bot {inverted = not $ inverted bot}

computeDirection :: Bot -> [String] -> Char 
computeDirection bot grille
    |next == 'X' && casseur bot == False = priorityDirection bot grille priority
    |next == '#' && inverted bot = priorityDirection bot grille priority
    |actualPos bot grille `elem` "SENW" = computeDirection bot {direction = actualPos bot grille} grille
    |otherwise = direction bot
    where   next = naturalNext bot grille
            priority = if (inverted bot) then "NWES" else "SEWN"

computeBotDirection :: Bot -> [String] -> Bot
computeBotDirection bot grille = bot {direction = computeDirection bot grille}

move :: Bot -> [String] -> Bot
move bot grille
    |actualPos bot grille == 'T' = bot {x = getOtherTeleportX bot, y = getOtherTeleportY}
    |otherwise = bot {x = x_pos, y= y_pos, nombre_mouvements = (nombre_mouvements bot) + 1}
    where   x_pos = px $ nextPos bot
            y_pos = py $ nextPos bot

compute :: Bot -> [String] -> Bot
compute bot grille
    |actualPos bot grille == '$' = bot
    |nombre_mouvements bot >= 2 * (length grille) * (length $ grille !! 0) = bot {historique = ["LOOP"]}
    |otherwise = compute ( move (computeBotDirection bot grille) grille) (computeGrid bot grille)
modifyAt ligne pos value= let (x, _:ys) = splitAt pos ligne in x ++ value:ys
modifyGrid grille x y value = modifyAt grille x (modifyAt (grille !! x) y value) 
computeGrid :: Bot -> [String] -> [[Char]]
computeGrid bot grille
    |casseur bot && actualPos bot grille == 'X' = modifyGrid grille (x bot) (y bot) ' '
    |otherwise = grille


main :: IO()
main = do
    grille <- replicateM 5 $ getLine
    print (getStartPoint grille)
    print (getCabPoint grille)
    let start = getStartPoint grille
    let cab = getCabPoint grille
    let bender = Bot (px $ start) (py start) 'S' False False [] 0
    print $ naturalNext bender grille
    return ()