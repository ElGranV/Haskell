valueFrom :: [Float] -> Float -> Float
valueFrom [] value = 0
valueFrom (x:xs) value = x*(value^(length(x:xs)-1)) + valueFrom xs value

value_from :: [Float] -> Float -> Float
value_from tab value = valueFrom (reverse tab) value