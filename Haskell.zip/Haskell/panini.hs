--On utilise la recherche de sous-chaines. A chaque étape on crée un tableau qui contient
--l'ensemble des sous chaines d'une certaine taille et on regarde si l'une d'entre elles est symétrique

--Extrait une sous-chaine d'une certaine taille à partir d'un départ (start)--
subChain :: String -> Int -> Int -> String
subChain chaine taille start = take taille (drop start chaine)

allSubs chaine taille = map (subChain chaine taille) [0..(length chaine)-taille]
all chaine = foldl (\acc list -> acc:list) [] (map (allSubs chaine) [length chaine, (length chaine)-1..1])

subChains :: String -> Int -> Int -> [String]
subChains chaine taille start
    |(taille + start) > (length chaine) = []
    |otherwise = firstChain:subChains chaine taille (start+1)
    where firstChain = subChain chaine taille start

--Extrait toutes les sous chaines d'une certaine taille dans un string--
allSubChains chaine taille = subChains chaine taille 0

--Revoie les string symétriques dans une liste de strings --
getSymetricSubChain :: [String] -> String
getSymetricSubChain [] = ""
getSymetricSubChain (x:xs)
    |x ==reverse x = x
    |otherwise = getSymetricSubChain xs

getSymetric chaine taille
    |taille == 0 = ""
    |sub == "" = getSymetric chaine (taille-1)
    |otherwise = sub
    where sub = getSymetricSubChain (allSubChains chaine taille)

panini :: String -> String
panini chaine = getSymetric chaine (length chaine)