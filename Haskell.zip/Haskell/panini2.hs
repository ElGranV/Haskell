subChain :: String -> Int -> Int -> String
subChain chaine taille start = take taille (drop start chaine)

allSubs chaine taille = map (subChain chaine taille) [0..(length chaine)-taille]

all chaine = foldl ( (map (allSubs chaine) [length chaine, (length chaine)-1 .. 0])